make clean;./configure;make;
