#ifndef NOPTIONS
#ifndef _config_h_INCLUDED
#define _config_h_INCLUDED

#include <stdbool.h>

struct kissat;

void kissat_configuration_usage (void);
bool kissat_has_configuration (const char *);

#endif
#endif
